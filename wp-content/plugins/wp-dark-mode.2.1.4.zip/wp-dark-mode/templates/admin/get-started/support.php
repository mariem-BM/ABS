<h3 class="tab-content-title">Support</h3>

<hr>
<br>

<div class="wp-dark-mode-shortcode-doc">

    <h3>Documentation Page: </h3>
    <a href="https://wppool.dev/docs/" target="_blank">https://wppool.dev/docs/</a>

    <hr>

    <h3>Youtube Playlist: </h3>
    <a href="https://wppool.dev/docs/" target="_blank">https://wppool.dev/docs/</a>

    <hr>

    <h3>Support Email: </h3>
    <a href="mailto:support@wppool.dev">support@wppool.dev</a>

</div>


